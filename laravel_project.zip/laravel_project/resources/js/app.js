require('./bootstrap');
window.$ = window.jQuery = require('jquery');
require('./script');

