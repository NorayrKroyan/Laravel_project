


<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Users Management</h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-success" href="<?php echo e(route('users.create')); ?>"> Create New User </a>
        </div>
    </div>
</div>


<?php if($message = Session::get('success')): ?>
<div class="alert alert-success">
  <p><?php echo e($message); ?></p>
</div>
<?php endif; ?>


<table class="table table-bordered" id="user-table">
 <tr>
   <th>No</th>
   <th>Name</th>
   <th>Photo</th>
   <th>Email</th>
   <th>Roles</th>
   <th width="280px">Action</th>
 </tr>
 <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr class="table-row-<?php echo e($user->id); ?>" data-id="<?php echo e($user->id); ?>">
    <td class="number"><?php echo e(++$i); ?></td>
    <td><?php echo e($user->name); ?></td>
    <td><img src="<?php echo e(asset('/storage/img/'. $user->avatar)); ?>" style="height:50px"></td>
    <td><?php echo e($user->email); ?></td>

    <td>
      <?php if(!empty($user->getRoleNames())): ?>
        <?php $__currentLoopData = $user->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <label class="badge badge-success text-dark"><?php echo e($v); ?></label>
       
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
    </td>
    <td>
     <?php if(!empty($user->getRoleNames())): ?>
        <?php $__currentLoopData = $user->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           
          <?php if($v === 'Admin'): ?> 
            <a class="btn btn-info" href="<?php echo e(route('users.show',$user->id)); ?>">Show</a>
            <!-- <a class="btn btn-primary" href="<?php echo e(route('users.edit',$user->id, $user->avatar)); ?>">Edit</a> -->
           
          <?php else: ?>
            <a class="btn btn-info" href="<?php echo e(route('users.show',$user->id)); ?>">Show</a>
            <a class="btn btn-primary" href="<?php echo e(route('users.edit',$user->id, $user->avatar)); ?>">Edit</a>
            <!-- <?php echo Form::open(['method' => 'POST','route' => ['users.destroy', $user->id],'style'=>'display:inline']); ?>

            <?php echo method_field('DELETE'); ?>

            <?php echo Form::submit('Delete', array('class' => 'btn btn-danger delete-confirm', 'id' =>'delete', 'data-id' => '<?php echo e($user-id); ?>') ); ?>

            <?php echo Form::close(); ?> -->
            <!-- <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="POST" style="display:inline" >
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>  -->
              <input type="button" class="btn btn-danger delete-confirm" data-id="<?php echo e($user->id); ?>" value="Delete">
            <!-- </form> -->


           
           <?php endif; ?>
       
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
           <!-- <a class="btn btn-info" href="<?php echo e(route('users.show',$user->id)); ?>">Show</a>
           <a class="btn btn-primary" href="<?php echo e(route('users.edit',$user->id)); ?>">Edit</a>
            <?php echo Form::open(['method' => 'DELETE','route' => ['users.destroy', $user->id],'style'=>'display:inline']); ?>

                <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

            <?php echo Form::close(); ?> -->
        
   
      <?php endif; ?>

    </td>
  </tr>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>


<?php echo $data->render(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/users/index.blade.php ENDPATH**/ ?>